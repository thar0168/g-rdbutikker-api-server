const mongoose = require("mongoose");

const butikkeSchema = new mongoose.Schema({
  navn: {
    type: String,
    required: true,
  },
  adresse: {
    type: String,
    required: true,
  },

  info: {
    type: String,
    default:"Beskrivelse følger..."
  },
  åbningstider:{
    type:String,
    required: true
},
billede:{
    type:String,
},
});

module.exports = mongoose.model("Butikke", butikkeSchema, "butikke");
