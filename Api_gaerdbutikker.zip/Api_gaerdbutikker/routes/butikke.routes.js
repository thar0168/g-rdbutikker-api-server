const Butikke = require('../model/butikke.model')
const express = require("express");
const router = express.Router();

//Multer - til upload af filer/images
//Multer-hånterer form-data
const multer = require('multer');
const upload = multer({

    //Hvordan/hvor filerene skal gemmes
    storage:multer.diskStorage({
        destination:function(req, file, cb) {
            cb(null,'public/images')
        },
            filename: function(req, file, cb) {
            //cb(null, file.originalname)//bevarer oprindeligt filnavn
                cb(null, Date.now() + "-" + file.originalname) //timestamp-hest.jpg
        }
    }),



    limits: { fileSize: 400000 }, // bytes
    fileFilter: function ( req, file, cb ) {
        let n = file.originalname.toLowerCase();
        if ( n.endsWith( '.jpg' ) || n.endsWith( '.gif' ) || n.endsWith( '.png' ) || n.endsWith( '.jpeg' ) ) {
            return cb( null, true ); // isValid( req ) 
        }
        cb( new Error( 'Kun png, jpg, gif og jpeg er tilladt!' ) );
    }

});



//GET - hent en butik ud fra ID
//-----Modtage ingenting
router.get("/:ID", async (req, res)=>{

    console.log("GET hent en butik")

    try {

        //Find alle i mangoDB
        const butikkes = await Butikke.findById(req.params.ID);

    res.status("200").json( butikkes)


        
    } catch (error) {
        console.log("FEJL:", error)
        res.status(500).json({besked:"Der er opstået en fejl"})
    }
})


//GET - hent alle
//-----Modtage ingenting
router.get("/", async (req, res)=>{

    console.log("GET alle")

    try {

        //Find alle i mangoDB
        const butikkes = await Butikke.find();

    res.status("200").json( butikkes)


        
    } catch (error) {
        console.log("FEJL:", error)
        res.status(500).json({besked:"Der er opstået en fejl"})
    }
})


//POST - opret ny
//---Modtage data til den nye
router.post("/", upload.single('image'), async (req, res) => {
  console.log("POST!", req.body);

  try {

   let nybutikke = new Butikke(req.body);
   //tilføj image til den nye butikke
   nybutikke.image = req.file.filename; //filename fra multer

    await nybutikke.save();
    res.status("200").json({ besked: "Der er oprettet", oprettet: nybutikke });

  } catch (error) {

    console.log("FEJL:", error);
    res.status(400).json({ besked: "Der er opstået fejl", oprettet: null });
  }
});


// PUT - ret en eksisterende ud fra ID
// --- Modtager en ID + rettet data

router.put( "/:ID", upload.single( 'image' ), async ( req, res ) => {
    console.log( "PUT!", req.body )
    try {
        // HVIS der er en fil/image med skal filename (fra multer) indsættes i request
        if ( req.file ) {
            req.body.image = req.file.filename; // filename fra multer
        }
        // Ret i DB send ID + body (rettede data) ... få den nye/rettede retur
        let rettetbuttike = await Butikke.findByIdAndUpdate( req.params.ID, req.body, { new: true } )
        res.status( "200" ).json( { besked: "Der er rettet", rettet: rettetbuttike } )
    } catch ( error ) {
        console.log( "FEJL: ", error )
        res.status( 400 ).json( { besked: "Der er opstået fejl", rettet: null } )
    }
} )







//DELETE - slået en ekisterende ud fra ID
//----Modtage en ID

router.delete("/:ID", async (req, res)=>{

    console.log("DELETE slet en butik")

    try {

        //Find butik i MongoDB og slet
        const butikkes = await Butikke.findByIdAndDelete (req.params.ID);

    res.status("200").json( {besked: "Butikke er slettet", slettet: butikkes})


        
    } catch (error) {
        console.log("FEJL:", error)
        res.status(500).json({besked:"Der er opstået en fejl"})
    }
})

module.exports = router;
