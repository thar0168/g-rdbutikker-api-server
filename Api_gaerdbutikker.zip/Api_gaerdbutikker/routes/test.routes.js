const Test = require('../model/test.model')
const express = require('express');
const router = express.Router();

//formdata
const formData = require("express-form-data")
router.use(formData.parse());

//GET - hent alle
//-----Modtage ingenting
router.get("/", async (req, res)=>{

    console.log("GET alle")

    try {

        //Find alle tester i mangoDB
        const testener = await Test.find();

    res.status("200").json( testener)


        
    } catch (error) {
        console.log("FEJL:", error)
        res.status(500).json({besked:"Der er opstået en fejl"})
    }
})


//GET - hent en butik ud fra ID
//----Modtage en ID

router.get("/:ID", async (req, res)=>{

    console.log("GET hent en butik!")

    try {

        //Find butik tester i mangoDB
        const teste = await Test.findById(req.params.ID);

    res.status("200").json( teste)


        
    } catch (error) {
        console.log("FEJL:", error)
        res.status(500).json({besked:"Der er opstået en fejl"})
    }
})


//GET - søg ud fra søgeord
//----MOdtage et søgeord

//POST - opret ny
//----Modtage data til den nye
router.post("/", async (req, res)=>{

    console.log("POST!", req.body)

    try {
            let nytest = new Test(req.body)
    await nytest.save();
    res.status("200").json( {besked:"Der er oprettet", oprettet:nytest})

    } catch (error) {

        console.log("FEJL:", error)
        res.status(400).json({besked:"Der er opstået fejl", oprettet:null})
    }

})

//PUT - ret en eksisterende ud fra ID
//-----Modtager en id + rettet data


//DELETE - slået en ekisterende ud fra ID
//----Modtage en ID


module.exports=router;