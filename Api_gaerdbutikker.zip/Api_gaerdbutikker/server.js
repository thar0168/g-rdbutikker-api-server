const express = require('express')
const cors = require('cors')
require('dotenv').config();//environment variabler






//--------Lav server
const server = express();


//------Håndter url-encoded og json dat (ved POST/PUT mv.)
server.use(express.json());//raw i postman
server.use(express.urlencoded({extended:true}));// x-www-form-urlencoded i postman
//Husk også form-data-Multer Eller form-data




// MongoDB-connection
const mongoose = require( 'mongoose' )
mongoose.connect( process.env.DATABASE_URL, { useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true } )
    .catch( fejl => console.log( "Fejl i kontakt til databasen", fejl ) )
const db = mongoose.connection; // kontakt til databasen
db.once( 'open', () => console.log( "Der er hul igennem til DB" ) )

//Servers velkomst --------------
server.get("/", async (req, res)=>{
    console.log("Her er roden af gårdbuttiker!")
    res.status("401").json({besked:"Her er serveres-velkommen til !!!"})
})

//ROUTES---------------
server.use("/test", require("./routes/test.routes"))
server.use("/butikkes", require("./routes/butikke.routes"))

//Lyt efter kald/request til gåredbutikker
server.listen(process.env.PORT,() => console.log("Din server lytter nu på port: " + process.env.PORT))

